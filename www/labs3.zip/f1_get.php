<?php
echo ("Привет, " . $_GET["userName"]);
echo ("<hr>");
echo ("Значение скрытого поля hideField равно " . $_GET["hideField"]);

?>