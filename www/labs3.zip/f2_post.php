<?php
echo ("Привет, " . $_POST["userName_post"]);
echo ("<hr>");
echo ("Значение скрытого поля hideField_post равно " . $_POST["hideField_post"]);
?>	