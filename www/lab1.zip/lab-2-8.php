<p>Takhaev Arseniy PI-321</p>

<?php
$arr = array(1 => "PHP111", 2 => "Mysql1");
echo ("$arr[1] $arr[2]");
?>