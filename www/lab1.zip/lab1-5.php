<p>Takhaev Arseniy PI-321</p>
<?php
$a=rand(-20,20);
$c=rand(-20,20);
$d=rand(-20,20);

echo ('4 * ' . "$c" . ' + ' . "$d" . " - 1" . '<br>' . '___________' . '<br>' . '<br>' . "$c" . ' - ' . "$a" . '<br>' . '______'.
	'<br>' . ' 2 ' . '<br>'. '<br>');

echo ('Answer equls is ' . ((4*$c) + $d - 1) / (c - ($a/2)));   















?>