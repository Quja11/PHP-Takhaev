<p>Takhaev Arseniy PI-321</p>
<p><b>Arithmetic operations</b></p>
<p>
<?php
	$x=rand(1,10);
	$y=rand(1,10);
	echo ($x . '+' . $y . '=' . ($x+$y) . '<br>');
	echo ($x . '-' . $y . '=' . ($x-$y) . '<br>');
	echo ($x . '*' . $y . '=' . ($x*$y) . '<br>');
	echo ($x . '/' . $y . '=' . ($x/$y) . '<br>');
?>
