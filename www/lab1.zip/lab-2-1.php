<p>Takhaev Arseniy PI-321</p>

<?php
$a=-1;
$b="";
if ($a){
	echo '$a = ' . "$a - true<br>";
}else{
	echo '$a = ' . "$a - false<br>";
}

if ($b){
	echo '$b = ' . "$b - true<br>";
}else{
	echo '$b = ' . "$b - false<br>";
}




?>