<p>Date and time:
</p>
<?php
$d=date("d.m.Y H:i");
echo($d);
?>
<ul>
	<p><i>Part 1</i></p>
	<li><a href="laba-1-1.y98709yq.beget.tech">Link to 1 page</a> 
	<li><a href="laba-1-2.y98709yq.beget.tech">Link to 1 page</a> 
	<li>Link to 2 page: http://php-takhaev/lab-1-2.php</li>
	<li>Link to 3 page: http://php-takhaev/lab-1-3.php</li>
</ul>

<ul>
	<p><i>Independent work Number One</i></p>
	<li>Link to 4 page: http://php-takhaev/lab1-5.php</li>
</ul>
