<p>the work was done by Takhaev Arseny PI-321</p>
<p>Date and time:
</p>
<?php
$d=date("d.m.Y H:i");
echo($d);
?>
<ul>
	<p><i><b>Part 1 (php introduction)</b></i></p>
	<li><a href="http://php-takhaev/index.php">Link to Main Page (Exercise 1-1 and 1-5)</a>

	<li><a href="http://php-takhaev/lab-1-1.php">Link to Exercise 1-2</a>

	<li><a href="http://php-takhaev/lab-1-2.php">Link to Exercise 1-3</a>

	<li><a href="http://php-takhaev/lab-1-3.php">Link to Exercise 1-4</a>
</ul>

<ul>
	<p><i><b>Independent work Number One</b></i></p>
	<li><a href="http://php-takhaev/lab1-5.php">Link to Task #1-1
	</a>
</ul>

<ul>
	<p><i><b>Part 2 (control structures)</b></i></p>
	<li><a href="http://php-takhaev/lab-2-1.php">Link to Exercise 1-6</a>

	<li><a href="http://php-takhaev/lab-2-2.php">Link to Exercise 1-7</a>

	<li><a href="http://php-takhaev/lab-2-3.php">Link to Exercise 1-8</a>

	<li><a href="http://php-takhaev/lab-2-4.php">Link to Exercise 1-9</a>

	<li><a href="http://php-takhaev/lab-2-5.php">Link to Exercise 1-10</a>

	<li><a href="http://php-takhaev/lab-2-6.php">Link to Exercise 1-11</a>

	<li><a href="http://php-takhaev/lab-2-7.php">Link to Exercise 1-12</a>

	<li><a href="http://php-takhaev/lab-2-8.php">Link to Exercise 1-13</a>

	<li><a href="http://php-takhaev/lab-2-9.php">Link to Exercise 1-14</a>	
</ul>

<ul>
	<p><i><b>Independent work Number Two</b></i></p>
	<li><a href="http://php-takhaev/lab-2-10.php">Link to Task #1-2
	</a>

	<li><a href="http://php-takhaev/lab-2-11.php">Link to Task #1-3
	</a>
</ul>




