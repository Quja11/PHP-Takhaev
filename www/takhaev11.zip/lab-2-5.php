<p>Takhaev Arseniy PI-321</p>

<?php
$i=0; $var=5;

while (++$i<=$var) {
	echo ($i . ' ');
}
echo '<br>';

while (--$var>=0){
	echo ($var+1 . ' ');
}

















?>