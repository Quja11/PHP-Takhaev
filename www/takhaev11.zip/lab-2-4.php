<p>Takhaev Arseniy PI-321</p>

<?php
$dn = rand(1,7);
print ($dn . "- weekday number <br>");
	switch($dn){
		case  1: print ("it's Monday");break;
		case  2: print ("it's Tuesday");break;         
		case  3: print ("it's Wednesday");break;        
		case  4: print ("it's Thursday");break;        
		case  5: print ("it's Friday");break;      
		case  6: print ("it's Saturday");break;        
		case  7: print ("it's Sunday");break;    
	}   
	

















?>